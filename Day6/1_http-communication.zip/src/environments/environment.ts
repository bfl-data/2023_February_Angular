export const environment = {
    production: true,
    postsUrl: "https://www.abc.com/posts"
};
