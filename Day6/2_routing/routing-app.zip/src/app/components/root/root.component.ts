import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html'
})
export class RootComponent implements OnInit, OnDestroy {
    constructor() { }

    ngOnInit() {
    }

    ngOnDestroy(): void {
    }
}