export const environment = {
    production: true,
    usersUrl: 'http://www.abc.com/api/users',
    accountUrl: 'http://www.abc.com/account/getToken'
};
