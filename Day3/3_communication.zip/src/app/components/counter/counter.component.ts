import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'counter',
  templateUrl: './counter.component.html'
})
export class CounterComponent {
  @Input() interval = 1;
  @Output() onMax = new EventEmitter<boolean>();

  _flag = false;
  _count = 0;
  _clickCount = 0;

  _manageClickCount() {
    this._clickCount += 1;
    if (this._clickCount > 9) {
      this._flag = true;
      this.onMax.emit(this._flag);
    }
  }

  _inc() {
    this._manageClickCount();
    this._count += this.interval;
  }

  _dec() {
    this._manageClickCount();
    this._count -= this.interval;
  }

  reset() {
    this._flag = false;
    this._count = 0;
    this._clickCount = 0;
    this.onMax.emit(this._flag);
  }
}
