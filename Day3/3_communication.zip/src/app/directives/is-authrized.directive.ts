import { Directive, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[isAuthrized]'
})
export class IsAuthrizedDirective implements OnInit {

  constructor(private templateRef: TemplateRef<any>, private viewContainerRef: ViewContainerRef) { }
  ngOnInit(): void {
    // To Do: You can get the value of authorization from some service call
    const flag = false;

    if (flag)
      this.viewContainerRef.createEmbeddedView(this.templateRef);
    else
      this.viewContainerRef.clear();
  }

}
