import { AuthorsService } from "./authors.service";
import { NAuthorsService } from "./nauthors.service";

export function AuthorFactory(enviornment: any) {
    if(enviornment["production"])
        return new NAuthorsService();
    else
        return new AuthorsService();
}