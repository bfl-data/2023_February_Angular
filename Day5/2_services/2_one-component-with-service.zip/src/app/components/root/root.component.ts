import { Component, Inject, OnInit } from '@angular/core';
import { authorList } from 'src/app/data/author-list-data';
import { env } from 'src/app/data/env';
import { Author } from 'src/app/models/author.interface';
import { AuthorFactory } from 'src/app/services/author-factory';
import { AuthorsService } from 'src/app/services/authors.service';
import { AUTHORS_LIST_TOKEN } from 'src/app/services/custom-di-token';

@Component({
    selector: 'app-root',
    templateUrl: './root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [
        // { provide: 'Authors', useValue: authorList }

        // { provide: AUTHORS_LIST_TOKEN, useValue: authorList },
        // { provide: 'NewAuthors', useExisting: AUTHORS_LIST_TOKEN }

        // { provide: AuthorsService, useClass: AuthorsService }
        // AuthorsService

        { provide: 'ENVIORNMENT', useValue: env },
        {
            provide: AuthorsService,
            useFactory: AuthorFactory,
            deps: ['ENVIORNMENT']
        }
    ]
})
export class RootComponent implements OnInit {
    list?: Array<Author>;
    selectedAuthor?: Author;

    // constructor(@Inject('Authors') private authors: Array<Author>) { }
    // constructor(@Inject(AUTHORS_LIST_TOKEN) private authors: Array<Author>) { }
    // constructor(@Inject('NewAuthors') private authors: Array<Author>) { }
    // constructor(@Inject(AuthorsService) private authorsService: any) { }
    // constructor(@Inject(AuthorsService) private authorsService: AuthorsService) { }
    constructor(private authorsService: AuthorsService) { }

    ngOnInit() {
        // this.list = this.authors;
        this.list = this.authorsService.Authors;
    }

    selectAuthor(a: Author) {
        this.selectedAuthor = a;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }
}