import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Author } from 'src/app/models/author.interface';
import { AuthorsService } from 'src/app/services/authors.service';
import { PubSubService } from 'src/app/services/pub-sub.service';

@Component({
  selector: 'app-author-quote',
  templateUrl: './author-quote.component.html',
  styleUrls: ['./author-quote.component.css']
})
export class AuthorQuoteComponent implements OnInit, OnDestroy {
  selectedAuthor?: Author;
  gsa_sub?: Subscription;

  constructor(private authorsService: AuthorsService, private pubsubService: PubSubService) { }

  ngOnInit(): void {
    this.gsa_sub = this.pubsubService.on('selected-author-updated').subscribe({
      next: () => {
        this.selectedAuthor = this.authorsService.SelectedAuthor;
      }
    });
  }

  ngOnDestroy(): void {
    this.gsa_sub?.unsubscribe();
  }
}
