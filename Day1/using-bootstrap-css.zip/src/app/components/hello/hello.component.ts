import { Component } from "@angular/core";

@Component({
    selector: 'app-hello',
    template: `
        <div class="container">
            <h1 class="text-primary text-center">
                Hello World!
            </h1>

            <h1 class="text-warning text-center">
                <span class="bi bi-activity"></span>
            </h1>
        </div>
    `
})
export class HelloComponent {}