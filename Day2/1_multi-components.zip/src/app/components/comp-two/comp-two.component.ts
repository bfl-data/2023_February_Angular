import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  template: `
    <h1 class="text-primary">
      Hello from Component Two
    </h1>
  `,
  styles: [
  ]
})
export class CompTwoComponent {

}
