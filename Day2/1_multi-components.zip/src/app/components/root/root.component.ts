import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styles: [
  ]
})
export class RootComponent {

}
