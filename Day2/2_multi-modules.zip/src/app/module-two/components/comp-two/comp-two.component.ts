import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  template: `
    <h1 class="text-primary">
      Hello from Component Two Module Two
    </h1>
    <app-scomp></app-scomp>
  `,
  styles: [
  ]
})
export class CompTwoComponent {

}
