import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ManishLibFeb23Module } from 'manish-lib-feb23';
import { RootComponent } from './components/root/root.component';
import { ModuleOneModule } from './module-one/module-one.module';
import { ModuleTwoModule } from './module-two/module-two.module';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    RootComponent
  ],
  imports: [
    BrowserModule,
    ModuleOneModule,
    ModuleTwoModule,
    SharedModule,
    ManishLibFeb23Module
  ],
  providers: [],
  bootstrap: [
    RootComponent
  ]
})
export class AppModule { }