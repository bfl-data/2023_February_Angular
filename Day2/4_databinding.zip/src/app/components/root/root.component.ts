import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styles: [
  ]
})
export class RootComponent {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  greetings: string;
  name!: string;

  constructor() {
    this.message = "Hello World!";
    this.flag = false;
    this.h = 300;
    this.w = 300;
    this.greetings = "Hello";
  }

  doChange() {
    this.message = new Date().toLocaleTimeString();
  }

  anchorClick1() {
    alert("Hello");
  }

  anchorClick2(e: Event) {
    alert("Hello");
    e.preventDefault();
  }

  doUpdate(n: string) {
    this.greetings = `Hello, ${n}`;
  }
}
